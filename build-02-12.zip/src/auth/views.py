import re
import json

import auth
import logs
import models

import flask
from flask import redirect
from flask import render_template
from flask import url_for
from flask.views import MethodView
import flask_login
from flask_login import current_user
from flask_login import login_required


class LoginView(MethodView):

    def get(self):
        if current_user is not None and current_user.is_authenticated():
            return redirect(url_for('home'))
        return render_template("login.html", failure=False)

    def post(self):
        data = flask.request.get_json()
        email = data.get('email')
        pw = data.get('password')
        auth.login(email, pw)
        if current_user.is_authenticated():
            next_url = flask.request.args.get('next', url_for("home"))
            logger.info("User: %s has logged in" % email)
            return json.dumps({"next_url": next_url})
        return "Failure"


class LogoutView(MethodView):

    def get(self):
        flask_login.logout_user()
        flask.session['email'] = None
        flask.session['name'] = None
        flask.session['permissiosn'] = None
        return redirect(url_for("login"))


class RegisterView(MethodView):

    def get(self):
        return render_template('register.html')

    def post(self):
        data = flask.request.get_json()
        name = data.get('displayName')
        email = data.get('email')
        emailConfirm = data.get('emailConfirm')
        password = data.get('password')
        passwordConfirm = data.get('passwordConfirm')


        user = models.User.query.filter_by(email=email).first()
        if user:
            if user.password:
                return "Failure, user already exists", 401
            else:
                user.password = password
        else:
            user = models.User(email, password, name)
            models.db.session.add(user)
            if data.get("author"):
                user.permissions = 2

        models.db.session.commit()

        auth.login(email, password)
        if current_user.is_authenticated():
            next_url = flask.request.args.get('next', url_for("home"))
            return json.dumps({"next_url": next_url})
        return render_template("register.html", failure=True)

logger = logs.get_logger()