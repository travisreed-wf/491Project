ALLOWED_EXTENSIONS = ["png", "jpg", "jpeg", "gif", "pdf", "txt"]
